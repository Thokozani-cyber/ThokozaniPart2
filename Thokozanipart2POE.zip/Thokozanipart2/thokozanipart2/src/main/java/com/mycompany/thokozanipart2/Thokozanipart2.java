/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.thokozanipart2;



import java.util.Scanner;

public class Thokozanipart2 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);

        System.out.println("Register Your Account");

        System.out.print("Enter your first name: ");
        String firstName = kb.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = kb.nextLine();

        System.out.print("Enter your username: ");
        String username = kb.nextLine();

        System.out.print("Enter your password: ");
        String password = kb.nextLine();

        System.out.print("Enter your cellphone number: ");
        String cellPhoneNumber = kb.nextLine();

        Login user = new Login(username, password, cellPhoneNumber);

        String registrationResult = user.registerUser();
        
        // --- COMPLETED SECTION ---
        System.out.println(registrationResult);
    }
}