/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.thokozanipart2;



import java.util.Random;
import java.util.List;
import java.util.ArrayList;

public class Messages {
    private static int totalMessages = 0;
    private static List<String> sentMessages = new ArrayList<>();

    private String messageID;
    private String recipient;
    private String messageText;
    private String messageHash;

    public Messages(String recipient, String messageText) {
        this.messageID = generateMessageID();
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageHash = createMessageHash();
    }

    private String generateMessageID() {
        Random rd = new Random();
        long id = (long) (rd.nextDouble() * 1000000000L);
        return String.format("%010d", id);
    }

    public boolean checkMessageID() {
        // --- COMPLETED SECTION ---
        // Checks if ID is exactly 10 characters long
        return this.messageID != null && this.messageID.length() == 10;
    }

    // Methods required by MessagesTest.java
    public String checkRecipientCell() {
        // Validates South African international format (+27 followed by 9 digits)
        if (this.recipient != null && this.recipient.matches("\\+27\\d{9}")) {
            return "cell phone number successfully captured.";
        } else {
            return "Cellphone number incorrectly formatted or doesnt contain the international code";
        }
    }

    public String validateMessageLength() {
        if (this.messageText != null && this.messageText.length() <= 250) {
            return "Message ready to send";
        } else {
            return "Message exceeds 250 characters by " + (this.messageText.length() - 250) + " characters; please reduce the size.";
        }
    }

    private String createMessageHash() {
        // Basic hash creation based on ID and Message text
        String idPart = this.messageID.substring(0, 2);
        String[] words = this.messageText.trim().split("\\s+");
        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length - 1].toUpperCase();
        return idPart + ":" + firstWord + lastWord;
    }
}