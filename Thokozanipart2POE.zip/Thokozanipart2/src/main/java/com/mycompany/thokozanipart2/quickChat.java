/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Student
 */

package com.mycompany.thokozanipart2;
import java.util.Scanner;

public class quickChat {

    private static final Scanner in = new Scanner(System.in);

    
    private static boolean login() {
        String user, pass;
        System.out.print("Username: ");
        user = in.nextLine();
        System.out.print("Password: ");
        pass = in.nextLine();
        return user.equals("admin") && pass.equals("Password1!"); 
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(in.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number.");
            }
        }
    }

    private static void sendFlow(int number) {
        String recipient, text, choiceResult;
        Message msg;
        int choice;

        do {
            System.out.print("Recipient cell number (e.g. +27718693002): ");
            recipient = in.nextLine().trim();
            msg = new Message(number, recipient, "x");
            System.out.println(msg.checkRecipientCell());
        } while (msg.checkRecipientCell().startsWith("Cell phone number successfully"));

        do {
            System.out.print("Message: ");
            text = in.nextLine();
            msg = new Message(number, recipient, text);
            if (text.length() > 250) {
                System.out.println("Please enter a message of less than 250 characters.");
            }
        } while (text.length() > 250 || text.isBlank());
        System.out.println(msg.checkMessageLength());

        choice = readInt("1) Send Message  2) Disregard Message  3) Store Message to send later: ");
        choiceResult = msg.sentMessage(choice);
        System.out.println(choiceResult);

        if (choice == 2 && readInt("> ") == 0) {
            System.out.println("Message deleted.");
        } else if (choice == 1) {
            System.out.println(msg.messageIdGenerated());
            System.out.println(msg.getDetails());
        }
    }

    public static void main(String[] args) {
        int max, entered = 0, option;
        boolean running = true;

        if (!login()) {
            System.out.println("Login failed. You must log in to send messages.");
            return;
        }
        System.out.println("Welcome to QuickChat.");
        max = readInt("How many messages do you wish to enter? ");

        while (running) {
            System.out.println("\n1) Send Messages\n2) Show recently sent messages\n3) Quit");
            option = readInt("Choose an option: ");
            switch (option) {
                case 1 -> {
                    if (entered >= max) {
                        System.out.println("You have entered all " + max + " messages.");
                    } else {
                        sendFlow(entered);
                        entered++;
                    }
                }
                case 2 -> System.out.println("Coming Soon.");
                case 3 -> running = false;
                default -> System.out.println("Invalid option.");
            }
        }
        System.out.println("Total messages sent: " + Message.returnTotalMessages());
    }
}