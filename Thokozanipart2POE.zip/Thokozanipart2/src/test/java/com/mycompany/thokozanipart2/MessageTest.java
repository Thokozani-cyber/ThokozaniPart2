/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.thokozanipart2;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class MessageTest {

    private Message msg1() {
        return new Message("0012345678", 0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
    }

    private Message msg2() {
        return new Message("0198765432", 1, "08575975889", "Hi Keegan, did you receive the payment?");
    }

    @BeforeEach
    void reset() { Message.resetState(); }

    @Test
    void messageLengthSuccess() {
        assertEquals("Message ready to send.", msg1().checkMessageLength());
    }

    @Test
    void messageLengthFailure() {
        Message m = new Message("0012345678", 0, "+27718693002", "a".repeat(255));
        assertEquals("Message exceeds 250 characters by 5; please reduce the size.", m.checkMessageLength());
    }

    @Test
    void recipientSuccess() {
        assertEquals("Cell phone number successfully captured.", msg1().checkRecipientCell());
    }

    @Test
    void recipientFailure() {
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
                msg2().checkRecipientCell());
    }

    @Test
    void hashIsCorrect() {
        assertEquals("00:0:HITONIGHT", msg1().createMessageHash());
    }

    @Test
    void hashesInLoop() {
        Message[] msgs = { msg1(), msg2() };
        String[] expected = { "00:0:HITONIGHT", "01:1:HIPAYMENT" };
        for (int i = 0; i < msgs.length; i++) {
            assertEquals(expected[i], msgs[i].createMessageHash());
        }
    }

    @Test
    void messageIdCreated() {
        Message m = new Message(0, "+27718693002", "Hello there");
        assertTrue(m.checkMessageID());
        assertEquals("Message ID generated: " + m.getMessageId(), m.messageIdGenerated());
    }

    @Test
    void sendDisregardStore() {
        assertEquals("Message successfully sent.", msg1().sentMessage(1));
        assertEquals("Press 0 to delete the message.", msg2().sentMessage(2));
        assertEquals("Message successfully stored.", msg1().sentMessage(3));
    }

    @Test
    void totalMessagesSent() {
        msg1().sentMessage(1);
        msg2().sentMessage(2);
        assertEquals(1, Message.returnTotalMessages());
    }
}